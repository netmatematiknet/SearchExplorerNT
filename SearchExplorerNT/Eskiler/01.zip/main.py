import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QTabWidget

from arama import AramaWidget
from agac import AgacWidget

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NT Arama ve Klasör Aracı")
        self.resize(1300, 800)

        tabs = QTabWidget()
        self.setCentralWidget(tabs)

        tabs.addTab(AramaWidget(), "Kelime Arama")
        tabs.addTab(AgacWidget(), "Klasör Ağacı")

def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
