import os
import mimetypes
import csv
import datetime

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QCheckBox, QPushButton,
    QFileDialog, QLabel, QTableWidget, QTableWidgetItem, QHeaderView,
    QAbstractItemView, QMessageBox, QFrame, QComboBox, QStyle, QLabel as QtLabel
)
from PyQt5.QtCore import Qt, QObject, pyqtSignal, QThread
from PyQt5.QtGui import QCursor, QIcon


def human_size(num_bytes):
    if num_bytes is None:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if num_bytes < 1024.0:
            return f"{num_bytes:.1f} {unit}"
        num_bytes /= 1024.0
    return f"{num_bytes:.1f} TB"


def truncate_text(text, max_len=40):
    text = text or ""
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + "..."


def search_in_file(path, query, case_sensitive):
    results = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for idx, line in enumerate(f, start=1):
                src = line if case_sensitive else line.lower()
                q = query if case_sensitive else query.lower()
                if q in src:
                    results.append(idx)
    except:
        return []
    return results


class SearchWorker(QObject):
    progress = pyqtSignal(dict)
    finished = pyqtSignal(int, int)

    def __init__(self, folder, query, case_sensitive, sname, scontent):
        super().__init__()
        self.folder = folder
        self.query = query
        self.case = case_sensitive
        self.sname = sname
        self.scontent = scontent

    def run(self):
        total = 0
        matched = 0

        for root, dirs, files in os.walk(self.folder):

            if self.sname:
                for d in dirs:
                    src = d if self.case else d.lower()
                    q = self.query if self.case else self.query.lower()
                    if q in src:
                        fullp = os.path.join(root, d)
                        try:
                            mtime = os.path.getmtime(fullp)
                        except:
                            mtime = None
                        self.progress.emit({
                            "filename": d, "file_type": "",
                            "folder": os.path.basename(root),
                            "path": fullp, "size": None,
                            "mtime": mtime, "is_dir": True, "line": None
                        })
                        matched += 1

            for file in files:
                total += 1
                fullp = os.path.join(root, file)
                ext = os.path.splitext(file)[1].lower()
                mime, _ = mimetypes.guess_type(fullp)
                ftype = ext if ext else mime or ""

                try:
                    size = os.path.getsize(fullp)
                except:
                    size = None

                try:
                    mtime = os.path.getmtime(fullp)
                except:
                    mtime = None

                name_match = False
                if self.sname:
                    src = file if self.case else file.lower()
                    q = self.query if self.case else self.query.lower()
                    if q in src:
                        name_match = True

                lines = []
                if self.scontent:
                    lines = search_in_file(fullp, self.query, self.case)

                if lines:
                    for ln in lines:
                        self.progress.emit({
                            "filename": file, "file_type": ftype,
                            "folder": os.path.basename(root),
                            "path": fullp, "size": size,
                            "mtime": mtime, "is_dir": False,
                            "line": ln
                        })
                        matched += 1

                elif name_match:
                    self.progress.emit({
                        "filename": file, "file_type": ftype,
                        "folder": os.path.basename(root),
                        "path": fullp, "size": size,
                        "mtime": mtime, "is_dir": False,
                        "line": None
                    })
                    matched += 1

        self.finished.emit(total, matched)


class AramaWidget(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout(self)
        top = QHBoxLayout()

        self.folder_edit = QLineEdit()
        btn_browse = QPushButton("Klasör Seç")
        self.query_edit = QLineEdit()
        self.query_edit.setPlaceholderText("Aranacak kelime...")

        self.chk_case = QCheckBox("Harfe duyarlı")
        self.chk_name = QCheckBox("İsimde ara")
        self.chk_content = QCheckBox("İçerikte ara")
        self.chk_name.setChecked(True)
        self.chk_content.setChecked(True)

        btn_search = QPushButton("Ara")

        top.addWidget(self.folder_edit)
        top.addWidget(btn_browse)
        top.addWidget(self.query_edit)
        top.addWidget(self.chk_case)
        top.addWidget(self.chk_name)
        top.addWidget(self.chk_content)
        top.addWidget(btn_search)
        layout.addLayout(top)

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels([
            "Dosya", "Tür", "Klasör", "Yol", "Boyut",
            "Tarih", "Satır", "Tip"
        ])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.table)

        self.status = QLabel("Hazır.")
        layout.addWidget(self.status)

        btn_browse.clicked.connect(self.on_browse)
        btn_search.clicked.connect(self.on_search)

    def on_browse(self):
        f = QFileDialog.getExistingDirectory(self, "Seç")
        if f:
            self.folder_edit.setText(f)

    def on_search(self):
        folder = self.folder_edit.text().strip()
        query = self.query_edit.text().strip()

        if not folder or not os.path.isdir(folder):
            QMessageBox.warning(self, "Hata", "Geçerli klasör seç.")
            return
        if not query:
            QMessageBox.warning(self, "Hata", "Kelime gir.")
            return

        self.table.setRowCount(0)
        self.status.setText("Aranıyor...")

        self.thread = QThread()
        self.worker = SearchWorker(
            folder, query,
            self.chk_case.isChecked(),
            self.chk_name.isChecked(),
            self.chk_content.isChecked()
        )
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.add_row)
        self.worker.finished.connect(self.finish)
        self.worker.finished.connect(self.thread.quit)

        self.thread.start()

    def add_row(self, d):
        row = self.table.rowCount()
        self.table.insertRow(row)

        self.table.setItem(row, 0, QTableWidgetItem(d["filename"]))
        self.table.setItem(row, 1, QTableWidgetItem(d["file_type"]))
        self.table.setItem(row, 2, QTableWidgetItem(d["folder"]))
        self.table.setItem(row, 3, QTableWidgetItem(d["path"]))

        self.table.setItem(row, 4, QTableWidgetItem(human_size(d["size"])))
        if d["mtime"]:
            t = datetime.datetime.fromtimestamp(d["mtime"]).strftime("%Y-%m-%d %H:%M")
        else:
            t = ""
        self.table.setItem(row, 5, QTableWidgetItem(t))

        self.table.setItem(row, 6, QTableWidgetItem(str(d["line"] or "")))
        self.table.setItem(row, 7, QTableWidgetItem("Klasör" if d["is_dir"] else "Dosya"))

    def finish(self, total, matched):
        self.status.setText(f"Bitti. {total} dosya, {matched} eşleşme.")
