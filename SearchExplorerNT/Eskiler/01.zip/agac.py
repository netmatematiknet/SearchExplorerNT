import os
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QTreeWidget, QTreeWidgetItem,
    QFileDialog, QPushButton, QHBoxLayout
)

class AgacWidget(QWidget):
    def __init__(self):
        super().__init__()

        layout = QVBoxLayout(self)
        top = QHBoxLayout()

        self.btn_select = QPushButton("Klasör Seç")
        top.addWidget(self.btn_select)

        layout.addLayout(top)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Ad", "Tür", "Boyut"])
        layout.addWidget(self.tree)

        self.btn_select.clicked.connect(self.select_folder)

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Klasör Seç")
        if folder:
            self.build_tree(folder)

    def build_tree(self, root):
        self.tree.clear()
        root_item = QTreeWidgetItem([os.path.basename(root), "Klasör", ""])
        self.tree.addTopLevelItem(root_item)
        self.add_items(root_item, root)
        self.tree.expandAll()

    def add_items(self, parent_item, path):
        try:
            for name in os.listdir(path):
                full = os.path.join(path, name)
                if os.path.isdir(full):
                    item = QTreeWidgetItem([name, "Klasör", ""])
                    parent_item.addChild(item)
                    self.add_items(item, full)
                else:
                    size = os.path.getsize(full)
                    item = QTreeWidgetItem([name, "Dosya", f"{size} B"])
                    parent_item.addChild(item)
        except:
            pass
